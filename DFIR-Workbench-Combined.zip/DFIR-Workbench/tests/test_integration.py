import unittest,subprocess,sys,tempfile,json,ast
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class Integration(unittest.TestCase):
 def run_cli(self,*args):
  return subprocess.run([sys.executable,str(ROOT/'dfir_kit.py'),*map(str,args)],capture_output=True,text=True,timeout=30)
 def test_source_compilation(self):
  for n in ['dfir_kit.py','dfir_workbench.py']:compile((ROOT/n).read_text(),n,'exec')
 def test_help(self):
  for cmd in ['init','windows','android','import','api','analyze','seal','verify','crypto']:
   self.assertEqual(self.run_cli(cmd,'--help').returncode,0,cmd)
 def test_lifecycle(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);c=p/'case'
   for args in [('init',c,'--collector','Test','--consent'),('verify',c)]:self.assertEqual(self.run_cli(*args).returncode,0)
   evidence=p/'sample.txt';evidence.write_text('synthetic evidence')
   self.assertEqual(self.run_cli('import',c,evidence).returncode,0)
   csv=p/'events.csv';csv.write_text('time,source,event_id\n2026-01-01T00:00:00Z,fixture,1102\n')
   self.assertEqual(self.run_cli('analyze',c,csv).returncode,0)
   findings=json.loads((c/'analysis/findings.json').read_text());self.assertEqual(len(findings),1)
   self.assertEqual(self.run_cli('verify',c).returncode,0)
   next((c/'imports').iterdir()).write_text('tampered')
   self.assertNotEqual(self.run_cli('verify',c).returncode,0)
 def test_requires_authorization(self):
  with tempfile.TemporaryDirectory() as d:self.assertNotEqual(self.run_cli('init',Path(d)/'c','--collector','Test').returncode,0)
 def test_gui_backend_colocated(self):
  text=(ROOT/'dfir_workbench.py').read_text();self.assertIn("with_name('dfir_kit.py')",text);self.assertTrue((ROOT/'dfir_kit.py').is_file())
