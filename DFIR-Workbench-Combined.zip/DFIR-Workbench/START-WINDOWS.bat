@echo off
cd /d "%~dp0"
python -u dfir_workbench.py
if errorlevel 1 pause
